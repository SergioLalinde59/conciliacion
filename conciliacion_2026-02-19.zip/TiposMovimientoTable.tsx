import { Pencil, Trash2 } from 'lucide-react'
import { Button } from '../../atoms/Button'
import type { TipoMovimiento } from '../../../types'

interface Props {
    tipos: TipoMovimiento[]
    loading: boolean
    onEdit: (tipo: TipoMovimiento) => void
    onDelete: (id: number) => void
}

export const TiposMovimientoTable = ({ tipos, loading, onEdit, onDelete }: Props) => {
    if (loading) return <div className="p-8 text-center text-gray-500">Cargando tipos...</div>
    if (tipos.length === 0) return <div className="p-8 text-center text-gray-500">No hay tipos registrados.</div>

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                        <th className="py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider w-20">ID</th>
                        <th className="py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Tipo de Movimiento</th>
                        <th className="py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right w-32">Acciones</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {tipos.map((tipo) => (
                        <tr key={tipo.id} className="hover:bg-gray-50 transition-colors">
                            <td className="py-3 px-4 text-sm text-gray-600 font-mono">#{tipo.id}</td>
                            <td className="py-3 px-4 text-sm font-medium text-gray-900">{tipo.nombre}</td>
                            <td className="py-3 px-4 text-right">
                                <div className="flex justify-end gap-2">
                                    <Button
                                        variant="ghost-warning"
                                        size="sm"
                                        onClick={() => onEdit(tipo)}
                                        className="!p-1.5"
                                        title="Editar"
                                    >
                                        <Pencil size={15} />
                                    </Button>
                                    <Button
                                        variant="ghost-danger"
                                        size="sm"
                                        onClick={() => { if (confirm('¿Eliminar?')) onDelete(tipo.id) }}
                                        className="!p-1.5"
                                        title="Eliminar"
                                    >
                                        <Trash2 size={15} />
                                    </Button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}
