import { useState, useEffect, useRef, useCallback } from 'react'
import { createPortal } from 'react-dom'
import { X, ChevronDown } from 'lucide-react'
import { Input } from '../atoms/Input'
import { EntityDisplay } from './entities/EntityDisplay'

interface ComboBoxOption {
    id: number | string
    nombre: string
}

interface ComboBoxProps {
    value: string
    onChange: (value: string) => void
    options: ComboBoxOption[]
    placeholder?: string
    label?: string
    required?: boolean
    disabled?: boolean
    autoFocus?: boolean
    className?: string
    error?: string
    icon?: React.ElementType
}

export const ComboBox = ({
    value,
    onChange,
    options,
    placeholder,
    label,
    required,
    disabled,
    autoFocus,
    className = '',
    error,
    icon: Icon
}: ComboBoxProps) => {
    const [searchTerm, setSearchTerm] = useState('')
    const [showDropdown, setShowDropdown] = useState(false)
    const [filteredOptions, setFilteredOptions] = useState<ComboBoxOption[]>(options)
    const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 })
    const inputRef = useRef<HTMLInputElement>(null)
    const dropdownRef = useRef<HTMLDivElement>(null)
    const containerRef = useRef<HTMLDivElement>(null)

    // Calcular posición del dropdown
    const updateDropdownPosition = useCallback(() => {
        if (containerRef.current) {
            const rect = containerRef.current.getBoundingClientRect()
            setDropdownPosition({
                top: rect.bottom + window.scrollY + 4,
                left: rect.left + window.scrollX,
                width: rect.width
            })
        }
    }, [])

    // Actualizar el texto mostrado cuando cambia el valor
    useEffect(() => {
        if (value) {
            const selected = options.find(opt => opt.id.toString() === value)
            if (selected) {
                setSearchTerm(`${selected.id} - ${selected.nombre}`)
            } else {
                // Si hay un valor pero no se encuentra en las opciones actuales
                // (por ejemplo si se borró de la base o no se ha cargado)
                setSearchTerm(value)
            }
        } else {
            setSearchTerm('')
        }
    }, [value, options])

    // Filtrar opciones cuando cambia el término de búsqueda
    useEffect(() => {
        if (searchTerm) {
            const term = searchTerm.toLowerCase()
            const filtered = options.filter(opt => {
                const fullText = `${opt.id} - ${opt.nombre}`.toLowerCase()
                const idStr = opt.id.toString()
                const nombre = opt.nombre.toLowerCase()
                return fullText.includes(term) || idStr.includes(term) || nombre.includes(term)
            })
            setFilteredOptions(filtered)
        } else {
            setFilteredOptions(options)
        }
    }, [searchTerm, options])

    // Cerrar dropdown al hacer clic fuera
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            const target = event.target as Node
            const isInsideContainer = containerRef.current?.contains(target)
            const isInsideDropdown = dropdownRef.current?.contains(target)
            if (!isInsideContainer && !isInsideDropdown) {
                setShowDropdown(false)
            }
        }
        document.addEventListener('mousedown', handleClickOutside)
        return () => document.removeEventListener('mousedown', handleClickOutside)
    }, [])

    // Actualizar posición del dropdown cuando se abre o cambia el tamaño
    useEffect(() => {
        if (showDropdown) {
            updateDropdownPosition()
            window.addEventListener('resize', updateDropdownPosition)
            window.addEventListener('scroll', updateDropdownPosition, true)
            return () => {
                window.removeEventListener('resize', updateDropdownPosition)
                window.removeEventListener('scroll', updateDropdownPosition, true)
            }
        }
    }, [showDropdown, updateDropdownPosition])

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = e.target.value
        setSearchTerm(newValue)
        setShowDropdown(true)

        // Si está vacío, limpiar selección
        if (!newValue) {
            onChange('')
        }
    }

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && searchTerm) {
            e.preventDefault()

            // 1. Intentar buscar por ID exacto primero
            // Permitir búsqueda exacta para strings también
            const option = options.find(opt => opt.id.toString() === searchTerm)
            if (option) {
                selectOption(option)
                return
            }

            const idMatch = searchTerm.match(/^\d+/)
            if (idMatch) {
                const id = parseInt(idMatch[0])
                const option = options.find(opt => opt.id === id || opt.id === id.toString())
                if (option) {
                    selectOption(option)
                    return
                }
            }

            // 2. Si no hay ID exacto, pero hay opciones filtradas, seleccionar la primera
            if (filteredOptions.length > 0) {
                selectOption(filteredOptions[0])
            }
        }

        if (e.key === 'Escape') {
            setShowDropdown(false)
            inputRef.current?.blur()
        }
    }

    const selectOption = (option: ComboBoxOption) => {
        onChange(option.id.toString())
        setSearchTerm(`${option.id} - ${option.nombre}`)
        setShowDropdown(false)
        inputRef.current?.blur()
    }

    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
        setShowDropdown(true)
        setFilteredOptions(options)
        e.target.select()
    }

    const clearSelection = (e: React.MouseEvent) => {
        e.stopPropagation()
        e.preventDefault()
        setSearchTerm('')
        onChange('')
        setFilteredOptions(options)
        inputRef.current?.focus()
    }

    const toggleDropdown = (e: React.MouseEvent) => {
        e.stopPropagation()
        e.preventDefault()
        if (showDropdown) {
            setShowDropdown(false)
        } else {
            setShowDropdown(true)
            inputRef.current?.focus()
        }
    }

    // Renderizar dropdown usando Portal para evitar problemas de overflow
    const renderDropdown = () => {
        if (!showDropdown || disabled) return null

        const dropdownContent = (
            <div
                ref={dropdownRef}
                style={{
                    position: 'absolute',
                    top: dropdownPosition.top,
                    left: dropdownPosition.left,
                    width: dropdownPosition.width,
                    zIndex: 9999
                }}
                className="bg-white border border-gray-200 rounded-lg shadow-xl max-h-60 overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-200"
            >
                {filteredOptions.length > 0 ? (
                    filteredOptions.map((option) => (
                        <div
                            key={option.id}
                            onMouseDown={(e) => {
                                e.preventDefault()
                                selectOption(option)
                            }}
                            className={`px-3 py-2.5 hover:bg-blue-50 cursor-pointer text-sm transition-colors border-b border-gray-50 last:border-0 flex items-center gap-2 ${value === option.id.toString() ? 'bg-blue-50 text-blue-600 font-medium' : 'text-gray-700'
                                }`}
                        >
                            <EntityDisplay
                                id={option.id}
                                nombre={option.nombre}
                                className="w-full"
                                idClassName="bg-gray-100 text-gray-500 min-w-[30px] text-center"
                            />
                        </div>
                    ))
                ) : (
                    <div className="px-4 py-4 text-center">
                        <p className="text-sm text-gray-400 italic">No se encontraron resultados</p>
                    </div>
                )}
            </div>
        )

        return createPortal(dropdownContent, document.body)
    }

    return (
        <div className={`relative ${className}`} ref={containerRef}>
            {label && (
                <label className="text-xs font-semibold text-gray-500 uppercase flex items-center gap-2 mb-1.5">
                    {Icon && <Icon size={14} />}
                    {label}{required && <span className="text-rose-500">*</span>}
                </label>
            )}

            <div className={`relative group ${error ? 'mb-0' : ''}`}>
                <Input
                    ref={inputRef}
                    type="text"
                    value={searchTerm}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    onFocus={handleFocus}
                    placeholder={placeholder || 'Buscar...'}
                    disabled={disabled}
                    required={required}
                    autoFocus={autoFocus}
                    className={`pr-10 ${error ? '!border-rose-300 focus:!border-rose-500 focus:!ring-rose-100' : ''}`}
                />

                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    {searchTerm && !disabled && (
                        <button
                            type="button"
                            onClick={clearSelection}
                            className="p-1 text-gray-300 hover:text-gray-500 rounded-md transition-colors"
                            tabIndex={-1}
                            title="Limpiar"
                        >
                            <X size={14} />
                        </button>
                    )}
                    <button
                        type="button"
                        className={`p-1 text-gray-400 rounded-md transition-colors ${!disabled ? 'hover:bg-gray-50 cursor-pointer' : ''}`}
                        onClick={!disabled ? toggleDropdown : undefined}
                        tabIndex={-1}
                    >
                        <ChevronDown size={14} className={`transition-transform duration-200 ${showDropdown ? 'rotate-180' : ''}`} />
                    </button>
                </div>
            </div>

            {renderDropdown()}
            {error && <span className="text-xs text-rose-500 ml-0.5 font-medium animate-fadeIn mt-1 block">{error}</span>}
        </div>
    )
}
