import React, { useState, useEffect, useMemo } from 'react'
import type { Movimiento, SugerenciaClasificacion, ContextoClasificacionResponse, Cuenta } from '../types'
import { apiService } from '../services/api'
import { EntitySelector } from '../components/molecules/entities/EntitySelector'
import { TerceroModal } from '../components/organisms/modals/TerceroModal'
import { MovimientoModal } from '../components/organisms/modals/MovimientoModal'

import { CurrencyDisplay } from '../components/atoms/CurrencyDisplay'
import { Save, Layers, Clock, CheckCircle, ArrowRight, Search, Copy, RefreshCw, Split, Trash2, RotateCcw, Link, UserPlus } from 'lucide-react'
import { DataTable } from '../components/molecules/DataTable'
import { TableHeaderCell } from '../components/atoms/TableHeaderCell'
import { fechaColumn, textoColumn, monedaColumn } from '../components/atoms/columnHelpers'
import { BatchClassificationPreviewTable } from '../components/organisms/BatchClassificationPreviewTable'
import { Button } from '../components/atoms/Button'
import { SelectorCuenta } from '../components/molecules/SelectorCuenta'
import { MessageModal } from '../components/molecules/MessageModal'
import { extraerNombreTercero } from '../utils/textUtils'

export const ClasificarMovimientosPage: React.FC = () => {
    // --- State ---
    const [pendientes, setPendientes] = useState<Movimiento[]>([])
    const [loading, setLoading] = useState(true)
    const [movimientoActual, setMovimientoActual] = useState<Movimiento | null>(null)

    // Sugerencias y Contexto
    const [sugerenciaData, setSugerenciaData] = useState<ContextoClasificacionResponse | null>(null)
    // const [loadingContexto, setLoadingContexto] = useState(false)

    // Form State
    const [terceroId, setTerceroId] = useState<number | null>(null)
    const [centroCostoId, setCentroCostoId] = useState<number | null>(null)
    const [conceptoId, setConceptoId] = useState<number | null>(null)
    const [detalle, setDetalle] = useState<string>('')
    const [descripcion, setDescripcion] = useState<string>('')
    const [referencia, setReferencia] = useState<string>('')

    // Modals
    const [showTerceroModal, setShowTerceroModal] = useState(false)
    const [showAdvancedModal, setShowAdvancedModal] = useState(false)
    const [modalInitialValues, setModalInitialValues] = useState<{ nombre?: string; alias?: string; referencia?: string }>({})

    // Batch Lote Modal
    const [showBatchModal, setShowBatchModal] = useState(false)
    const [batchPreview, setBatchPreview] = useState<Movimiento[]>([])
    const [batchPatron, setBatchPatron] = useState('')
    const [batchReferencia, setBatchReferencia] = useState<string | undefined>(undefined)
    const [loadingBatch, setLoadingBatch] = useState(false)
    const [batchSelectedIds, setBatchSelectedIds] = useState<Set<number>>(new Set())
    const [similaresPendientes, setSimilaresPendientes] = useState<number>(0)

    // Modal Clasificar Similares


    // Catalogos
    const [centrosCostos, setCentrosCostos] = useState<{ id: number, nombre: string }[]>([])
    const [conceptos, setConceptos] = useState<{ id: number, nombre: string, centro_costo_id?: number }[]>([])
    const [terceros, setTerceros] = useState<{ id: number, nombre: string }[]>([])
    const [cuentas, setCuentas] = useState<Cuenta[]>([])

    // Filtro por cuenta
    const [filtroCuentaId, setFiltroCuentaId] = useState<string>('')

    // Modal de confirmación de eliminación
    const [showDeleteModal, setShowDeleteModal] = useState(false)
    const [deleting, setDeleting] = useState(false)
    const [msgModal, setMsgModal] = useState<{message: string; type: 'error' | 'warning' | 'success'} | null>(null)

    // --- Effects ---

    // 1. Cargar Pendientes y Catálogos
    useEffect(() => {
        cargarDatosIniciales()
    }, [])

    const cargarDatosIniciales = async () => {
        setLoading(true)
        try {
            const [pends, cats, ctas] = await Promise.all([
                apiService.movimientos.obtenerPendientes(),
                apiService.catalogos.obtenerTodos(),
                apiService.cuentas.listar()
            ])
            // Ordenar de más antiguo a más nuevo
            setPendientes(pends.sort((a, b) => a.fecha.localeCompare(b.fecha)))
            setCentrosCostos(cats.centros_costos)
            setConceptos(cats.conceptos)
            setTerceros(cats.terceros)
            setCuentas(ctas)
        } catch (error) {
            console.error("Error cargando datos:", error)
        } finally {
            setLoading(false)
        }
    }

    // 2. Cargar Sugerencia cuando cambia el movimiento actual
    useEffect(() => {
        if (!movimientoActual) {
            setSugerenciaData(null)
            setSimilaresPendientes(0)
            limpiarFormulario()
            return
        }

        const cargarSugerencia = async () => {
            // setLoadingContexto(true)
            try {
                const data = await apiService.clasificacion.obtenerSugerencia(movimientoActual.id) as ContextoClasificacionResponse
                setSugerenciaData(data)
                aplicarSugerencia(data.sugerencia)

                // Cargar conteo de similares para el botón de lote
                if (data.sugerencia.razon) {
                    const palabras = movimientoActual.descripcion.split(' ')
                    const patronDefault = palabras.slice(0, 2).join(' ')
                    const ref = movimientoActual.referencia || undefined
                    try {
                        const preview = await apiService.clasificacion.previewLote(patronDefault, ref) as Movimiento[]
                        setSimilaresPendientes(preview.length)
                    } catch {
                        setSimilaresPendientes(0)
                    }
                } else {
                    setSimilaresPendientes(0)
                }
            } catch (error) {
                console.error("Error cargando sugerencia:", error)
            } finally {
                // setLoadingContexto(false)
            }
        }
        cargarSugerencia()
    }, [movimientoActual])

    // --- Helpers ---

    const limpiarFormulario = () => {
        setTerceroId(null)
        setCentroCostoId(null)
        setConceptoId(null)
        setDetalle('')
        setDescripcion('')
        setReferencia('')
    }

    const aplicarSugerencia = (sug: SugerenciaClasificacion) => {
        // Always update form state, clearing previous values if suggestion is null
        setTerceroId(sug.tercero_id ?? null)
        setCentroCostoId(sug.centro_costo_id ?? null)
        setConceptoId(sug.concepto_id ?? null)
        // Keep current detalle, descripcion and referencia from movimientoActual
        if (movimientoActual) {
            setDetalle(movimientoActual.detalle || '')
            setDescripcion(movimientoActual.descripcion || '')
            setReferencia(movimientoActual.referencia || '')
        }
    }

    const seleccionarMovimiento = (mov: Movimiento) => {
        setMovimientoActual(mov)
        setDetalle(mov.detalle || '')
        setDescripcion(mov.descripcion || '')
        setReferencia(mov.referencia || '')
    }

    // Filtrar pendientes por cuenta seleccionada
    const pendientesFiltrados = useMemo(() => {
        if (!filtroCuentaId) return pendientes
        const cuentaId = parseInt(filtroCuentaId)
        return pendientes.filter(m => m.cuenta_id === cuentaId)
    }, [pendientes, filtroCuentaId])

    // Determinar si el movimiento actual permite ser eliminado (solo cuentas de efectivo)
    const permiteBorrar = useMemo(() => {
        if (!movimientoActual) return false
        const cuenta = cuentas.find(c => c.id === movimientoActual.cuenta_id)
        return cuenta?.configuracion?.permite_borrar ?? false
    }, [movimientoActual, cuentas])

    const eliminarMovimiento = async () => {
        if (!movimientoActual) return

        setDeleting(true)
        try {
            await apiService.movimientos.eliminar(movimientoActual.id)
            // Éxito: Remover de pendientes y cerrar modal
            setPendientes(prev => prev.filter(m => m.id !== movimientoActual.id))
            setMovimientoActual(null)
            setShowDeleteModal(false)
        } catch (error) {
            console.error("Error eliminando:", error)
            setMsgModal({message: "Error al eliminar: " + error, type: 'error'})
        } finally {
            setDeleting(false)
        }
    }

    const guardarClasificacion = async () => {
        if (!movimientoActual || !terceroId) {
            setMsgModal({message: "Por favor seleccione un Tercero (Identidad del Movimiento)", type: 'warning'})
            return
        }

        try {
            const { detalles, ...movRest } = movimientoActual
            const payload = {
                ...movRest,
                tercero_id: terceroId,
                centro_costo_id: centroCostoId,
                concepto_id: conceptoId,
                detalle: detalle,
                descripcion: descripcion,
                referencia: referencia,
            }

            await apiService.movimientos.actualizar(movimientoActual.id, payload)

            // Éxito: Remover de pendientes
            setPendientes(prev => prev.filter(m => m.id !== movimientoActual.id))
            setMovimientoActual(null)

        } catch (error) {
            console.error("Error guardando:", error)
            setMsgModal({message: "Error al guardar: " + error, type: 'error'})
        }
    }

    const abrirModalLote = async () => {
        if (!movimientoActual) return
        if (!terceroId || !centroCostoId || !conceptoId) {
            setMsgModal({message: "Por favor complete Tercero, Centro de Costo y Concepto antes de aplicar en lote", type: 'warning'})
            return
        }

        const palabras = movimientoActual.descripcion.split(' ')
        // Default pattern: First 2 words, but user can edit now
        const patronDefault = palabras.slice(0, 2).join(' ')
        const ref = movimientoActual.referencia || undefined

        setBatchPatron(patronDefault)
        setBatchReferencia(ref)
        setBatchSelectedIds(new Set())
        await obtenerPreviewLote(patronDefault, ref)
        setShowBatchModal(true)
    }

    const obtenerPreviewLote = async (patron: string, ref?: string) => {
        setLoadingBatch(true)
        try {
            const preview = await apiService.clasificacion.previewLote(patron, ref) as Movimiento[]
            setBatchPreview(preview)
            // Select all by default
            setBatchSelectedIds(new Set(preview.map(m => m.id)))
        } catch (error) {
            console.error("Error obteniendo preview:", error)
            setMsgModal({message: "Error al obtener preview: " + error, type: 'error'})
        } finally {
            setLoadingBatch(false)
        }
    }

    const handleRefreshPreview = () => {
        if (!batchPatron.trim()) return
        obtenerPreviewLote(batchPatron, batchReferencia)
    }

    const confirmarLote = async () => {
        if (!batchPatron || !terceroId || !centroCostoId || !conceptoId) return
        if (batchSelectedIds.size === 0) return

        try {
            const dto = {
                // patron: batchPatron, // Ya no usamos patron para el guardado final, sino IDs explícitos
                movimiento_ids: Array.from(batchSelectedIds),
                tercero_id: terceroId,
                centro_costo_id: centroCostoId,
                concepto_id: conceptoId
            }
            await apiService.clasificacion.clasificarLote(dto)
            setShowBatchModal(false)
            setBatchPreview([])
            // Recargar todo
            cargarDatosIniciales()
            setMovimientoActual(null)
        } catch (error) {
            setMsgModal({message: "Error en lote: " + error, type: 'error'})
        }
    }

    const abrirModalTercero = () => {
        const nombreExtraido = extraerNombreTercero(movimientoActual?.descripcion || '')
        setModalInitialValues({
            nombre: nombreExtraido,
            alias: movimientoActual?.descripcion || '',
            referencia: movimientoActual?.referencia || ''
        })
        setShowTerceroModal(true)
    }

    const handleAsociarTercero = async () => {
        if (!movimientoActual || !sugerenciaData?.sugerencia.tercero_id) return
        try {
            await apiService.terceros.crearDescripcion({
                terceroid: sugerenciaData.sugerencia.tercero_id,
                descripcion: movimientoActual.descripcion,
                referencia: movimientoActual.referencia || undefined
            })
            setMsgModal({ message: "Referencia asociada al tercero exitosamente", type: 'success' })
        } catch (error) {
            setMsgModal({ message: "Error asociando referencia: " + error, type: 'error' })
        }
    }

    const handleGuardarTercero = async (nombre: string, alias?: string) => {
        try {
            const nuevoTercero = await apiService.terceros.crear({
                tercero: nombre
            })
            // Crear primer alias (descripción + referencia del extracto) si se proporcionó
            if (alias) {
                try {
                    await apiService.terceros.crearDescripcion({
                        terceroid: nuevoTercero.id,
                        descripcion: alias,
                        referencia: movimientoActual?.referencia || undefined
                    })
                } catch (err) {
                    console.warn("Tercero creado pero error al crear alias:", err)
                }
            }
            // Update list
            setTerceros(prev => [...prev, nuevoTercero])
            // Select it
            setTerceroId(nuevoTercero.id)
            setShowTerceroModal(false)
        } catch (error) {
            console.error(error)
            setMsgModal({message: "Error creando tercero", type: 'error'})
        }
    }

    const handleGuardarAvanzado = async (payload: any) => {
        if (!movimientoActual) return
        try {
            await apiService.movimientos.actualizar(movimientoActual.id, payload)
            // Éxito: Remover de pendientes
            setPendientes(prev => prev.filter(m => m.id !== movimientoActual.id))
            setMovimientoActual(null)
            setShowAdvancedModal(false)
        } catch (error) {
            console.error(error)
            setMsgModal({message: "Error guardando avanzado: " + error, type: 'error'})
            throw error // Re-throw to let modal know it failed if needed
        }
    }



    // --- Render ---

    return (
        <div className="flex h-screen bg-gray-100 overflow-hidden">
            {/* Left Panel: List */}
            <div className="w-1/3 bg-white border-r flex flex-col">
                <div className="p-4 border-b bg-gray-50">
                    <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                        <Layers className="h-5 w-5 text-blue-600" />
                        Por Clasificar ({pendientesFiltrados.length})
                    </h2>
                    <div className="mt-3">
                        <SelectorCuenta
                            value={filtroCuentaId}
                            onChange={setFiltroCuentaId}
                            soloConciliables={true}
                            showTodas={true}
                            label=""
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                    {loading ? (
                        <div className="p-8 text-center text-gray-500">Cargando...</div>
                    ) : pendientesFiltrados.length === 0 ? (
                        <div className="p-8 text-center text-green-600">
                            <CheckCircle className="h-12 w-12 mx-auto mb-2" />
                            <p>{filtroCuentaId ? 'Sin movimientos en esta cuenta' : '¡Todo clasificado!'}</p>
                        </div>
                    ) : (
                        <div className="divide-y">
                            {pendientesFiltrados.map(mov => (
                                <div
                                    key={mov.id}
                                    onClick={() => seleccionarMovimiento(mov)}
                                    className={`p-4 cursor-pointer hover:bg-blue-50 transition-colors ${movimientoActual?.id === mov.id ? 'bg-blue-100 border-l-4 border-blue-600' : ''
                                        }`}
                                >
                                    <div className="flex justify-between items-center mb-1">
                                        <div className="flex items-center gap-1.5 flex-nowrap">
                                            {mov.cuenta_display && (
                                                <span className="text-xs text-blue-600 font-medium whitespace-nowrap">
                                                    {mov.cuenta_display}
                                                </span>
                                            )}
                                            {/* USD indicator for MasterCard account */}
                                            {mov.cuenta_display?.toLowerCase().includes('mc') &&
                                                (mov.usd || mov.descripcion?.toLowerCase().includes('usd')) && (
                                                    <span className="text-xs bg-green-100 text-green-700 px-1 py-0.5 rounded font-semibold shrink-0">
                                                        USD
                                                    </span>
                                                )}
                                            <span className="text-xs font-semibold text-gray-500 whitespace-nowrap shrink-0">{mov.fecha}</span>
                                        </div>
                                        <CurrencyDisplay
                                            value={mov.cuenta_display?.toLowerCase().includes('usd') || (mov.usd && mov.usd !== 0) ? (mov.usd || 0) : mov.valor}
                                            currency={mov.cuenta_display?.toLowerCase().includes('usd') || (mov.usd && mov.usd !== 0) ? 'USD' : 'COP'}
                                            className="text-sm font-bold shrink-0 ml-2"
                                            alignRight={false}
                                        />
                                    </div>
                                    <div className="flex items-start gap-2">
                                        {mov.referencia && (
                                            <span className="text-xs text-gray-500 flex items-center gap-1 shrink-0">
                                                <span className="bg-gray-200 px-1 rounded">REF</span> {mov.referencia}
                                            </span>
                                        )}
                                        <span className="text-sm text-gray-800 font-medium truncate" title={mov.descripcion}>
                                            {mov.referencia && <span className="text-gray-400 mx-1">-</span>}
                                            {mov.descripcion}
                                        </span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Right Panel: Editor */}
            <div className="flex-1 flex flex-col bg-gray-50 overflow-y-auto">
                {movimientoActual ? (
                    <div className="p-4">
                        {/* Header Movimiento */}
                        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <h1 className="text-2xl font-bold text-gray-900 mb-1">Editor de Clasificación</h1>
                                    <p className="text-gray-500 text-sm">ID: {movimientoActual.id} | {movimientoActual.fecha ? new Date(movimientoActual.fecha).toLocaleDateString('es-CO') : '-'}</p>
                                </div>
                                <div className="text-right">
                                    <CurrencyDisplay
                                        value={movimientoActual.cuenta_display?.toLowerCase().includes('usd') || (movimientoActual.usd && movimientoActual.usd !== 0) ? (movimientoActual.usd || 0) : movimientoActual.valor}
                                        currency={movimientoActual.cuenta_display?.toLowerCase().includes('usd') || (movimientoActual.usd && movimientoActual.usd !== 0) ? 'USD' : 'COP'}
                                        className="text-3xl font-bold"
                                    />
                                    <div className="text-gray-500 text-sm">{movimientoActual.cuenta_display}</div>
                                </div>
                            </div>

                            <div className="bg-blue-50 p-4 rounded-md border border-blue-100 mb-3">
                                <p className="text-lg text-blue-900 font-medium">{movimientoActual.descripcion}</p>
                                {movimientoActual.referencia && (
                                    <p className="text-sm text-blue-700 mt-1">Ref: {movimientoActual.referencia}</p>
                                )}
                            </div>

                            {/* Sugerencia Bar */}
                            {sugerenciaData?.sugerencia.razon && (
                                <div className="bg-green-50 px-4 py-2 rounded border border-green-200 text-green-800 text-sm flex items-center gap-2 mb-3">
                                    <Search className="h-4 w-4" />
                                    <strong>Sugerencia:</strong> {sugerenciaData.sugerencia.razon}
                                </div>
                            )}

                            {/* Alert: Referencia nueva — con o sin tercero sugerido */}
                            {sugerenciaData?.referencia_no_existe && (() => {
                                const terceroSugeridoNombre = terceros.find(t => t.id === sugerenciaData.sugerencia.tercero_id)?.nombre
                                const nombreExtraido = extraerNombreTercero(movimientoActual?.descripcion || '')

                                if (terceroSugeridoNombre) {
                                    // Case A: referencia nueva PERO hay un tercero sugerido por texto
                                    return (
                                        <div className="bg-amber-50 px-4 py-3 rounded border border-amber-200 text-amber-900 text-sm mb-3">
                                            <div className="flex items-start gap-2 mb-2">
                                                <span className="text-amber-500 font-bold text-lg leading-none mt-0.5">!</span>
                                                <span>
                                                    Referencia <code className="bg-amber-100 px-1 rounded font-mono">{sugerenciaData.referencia}</code> es nueva.
                                                    El tercero <strong>{terceroSugeridoNombre}</strong> se sugiere por similitud de descripción.
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-2 ml-6">
                                                <button
                                                    onClick={handleAsociarTercero}
                                                    className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition text-sm font-medium whitespace-nowrap flex items-center gap-1.5"
                                                >
                                                    <Link className="h-3.5 w-3.5" />
                                                    Asociar a {terceroSugeridoNombre}
                                                </button>
                                                <button
                                                    onClick={abrirModalTercero}
                                                    className="bg-orange-500 text-white px-3 py-1 rounded hover:bg-orange-600 transition text-sm font-medium whitespace-nowrap flex items-center gap-1.5"
                                                >
                                                    <UserPlus className="h-3.5 w-3.5" />
                                                    Crear {nombreExtraido}
                                                </button>
                                            </div>
                                        </div>
                                    )
                                }

                                // Case B: referencia nueva Y no hay sugerencia de tercero
                                return (
                                    <div className="bg-orange-50 px-4 py-3 rounded border border-orange-200 text-orange-800 text-sm flex items-center justify-between gap-4 mb-3">
                                        <div className="flex items-center gap-2">
                                            <span className="text-orange-500 font-bold text-lg">⚠</span>
                                            <span>
                                                Tercero no encontrado para la referencia <code className="bg-orange-100 px-1 rounded font-mono">{sugerenciaData.referencia}</code>
                                            </span>
                                        </div>
                                        <button
                                            onClick={abrirModalTercero}
                                            className="bg-orange-500 text-white px-3 py-1 rounded hover:bg-orange-600 transition text-sm font-medium whitespace-nowrap flex items-center gap-1.5"
                                        >
                                            <UserPlus className="h-3.5 w-3.5" />
                                            Crear {nombreExtraido}
                                        </button>
                                    </div>
                                )
                            })()}

                            {/* Form Area */}
                            <div className="space-y-1.5">
                                {/* Tercero (Header Identity) */}
                                <div>
                                    <label className="block text-sm font-bold text-blue-800 mb-1 flex items-center gap-1">
                                        Tercero (Identidad del Movimiento)
                                        <span className="text-[10px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded-full uppercase tracking-wider font-bold">Encabezado</span>
                                    </label>
                                    <EntitySelector
                                        options={terceros}
                                        value={terceroId ? terceroId.toString() : ""}
                                        onChange={(val) => setTerceroId(val ? parseInt(val) : null)}
                                        placeholder="Buscar tercero..."
                                    />
                                    <div className="mt-1 flex items-center gap-3">
                                        <button
                                            onClick={abrirModalTercero}
                                            className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                                        >
                                            + Nuevo Tercero
                                        </button>
                                        {(terceroId || centroCostoId || conceptoId) && (
                                            <button
                                                onClick={() => { setTerceroId(null); setCentroCostoId(null); setConceptoId(null) }}
                                                className="text-xs text-gray-400 hover:text-red-500 font-medium flex items-center gap-1 transition-colors"
                                            >
                                                <RotateCcw className="h-3 w-3" />
                                                Limpiar clasificación
                                            </button>
                                        )}
                                    </div>
                                </div>

                                {/* Grupo y Concepto en la misma línea */}
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <EntitySelector
                                            label="Centro de Costo"
                                            options={centrosCostos}
                                            value={centroCostoId ? centroCostoId.toString() : ""}
                                            onChange={(val) => {
                                                setCentroCostoId(val ? parseInt(val) : null)
                                                setConceptoId(null)
                                            }}
                                            placeholder="Seleccionar centro de costo..."
                                        />
                                    </div>

                                    <div>
                                        <EntitySelector
                                            label="Concepto"
                                            options={conceptos.filter(c => !centroCostoId || c.centro_costo_id === centroCostoId)}
                                            value={conceptoId ? conceptoId.toString() : ""}
                                            onChange={(val) => setConceptoId(val ? parseInt(val) : null)}
                                            placeholder="Seleccionar concepto..."
                                        />
                                    </div>
                                </div>

                                {/* Detalle (notas adicionales) */}
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Detalle / Notas</label>
                                    <input
                                        type="text"
                                        value={detalle}
                                        onChange={(e) => setDetalle(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        placeholder="Notas adicionales del movimiento..."
                                    />
                                </div>

                                {/* Descripción y Referencia */}
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
                                        <input
                                            type="text"
                                            value={descripcion}
                                            onChange={(e) => setDescripcion(e.target.value)}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            placeholder="Descripción del movimiento..."
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Referencia</label>
                                        <input
                                            type="text"
                                            value={referencia}
                                            onChange={(e) => setReferencia(e.target.value)}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            placeholder="Referencia..."
                                        />
                                    </div>
                                </div>

                                {/* Botones en una sola línea */}
                                <div className="flex items-center gap-3 pt-2">
                                    <button
                                        onClick={guardarClasificacion}
                                        className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition shadow-md font-medium"
                                    >
                                        <Save className="h-5 w-5" />
                                        Guardar Clasificación
                                    </button>

                                    {sugerenciaData?.sugerencia.razon && (
                                        <button
                                            onClick={abrirModalLote}
                                            disabled={loadingBatch || similaresPendientes < 2}
                                            className="flex-1 flex items-center justify-center gap-2 bg-white text-purple-700 border border-purple-200 py-3 px-4 rounded-lg hover:bg-purple-50 transition font-medium disabled:opacity-50"
                                            title={similaresPendientes < 2 ? 'Se requieren al menos 2 movimientos similares' : `Aplicar clasificación a ${similaresPendientes} movimientos similares`}
                                        >
                                            <Layers className="h-5 w-5" />
                                            {loadingBatch ? 'Cargando...' : `Aplicar a Todos (${similaresPendientes} similares)`}
                                        </button>
                                    )}

                                    <button
                                        onClick={() => setShowAdvancedModal(true)}
                                        className="flex items-center justify-center gap-2 text-purple-600 hover:text-purple-800 py-3 px-4 font-medium transition-colors"
                                        title="Edición Avanzada / Dividir"
                                    >
                                        <Split className="h-5 w-5" />
                                    </button>

                                    {permiteBorrar && (
                                        <button
                                            onClick={() => setShowDeleteModal(true)}
                                            className="flex items-center justify-center gap-2 text-red-500 hover:text-red-700 py-3 px-4 font-medium transition-colors"
                                            title="Eliminar movimiento"
                                        >
                                            <Trash2 className="h-5 w-5" />
                                        </button>
                                    )}

                                    <button
                                        onClick={() => setMovimientoActual(null)}
                                        className="flex items-center justify-center gap-2 text-gray-500 hover:text-gray-700 py-3 px-4"
                                    >
                                        <ArrowRight className="h-4 w-4" />
                                        Saltar
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* History Context - SIEMPRE MOSTRAR */}
                        {sugerenciaData && (
                            <div className="bg-white rounded-lg shadow-sm p-4">
                                <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                    <Clock className="h-5 w-5 text-gray-400" />
                                    Historial Relacionado ({sugerenciaData.contexto.length})
                                </h3>

                                {sugerenciaData.contexto.length === 0 ? (
                                    <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                                        <p className="text-gray-500 text-sm mb-2">
                                            📋 No se encontraron registros similares para este movimiento
                                        </p>
                                        <p className="text-gray-400 text-xs">
                                            Esto puede ocurrir si es un movimiento nuevo o único
                                        </p>
                                    </div>
                                ) : (
                                    <div className="border rounded-xl overflow-hidden shadow-sm">
                                        <DataTable
                                            data={sugerenciaData.contexto}
                                            columns={[
                                                {
                                                    key: 'actions',
                                                    header: <TableHeaderCell>Acción</TableHeaderCell>,
                                                    width: 'w-16',
                                                    align: 'center',
                                                    accessor: (ctx: any) => (
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            className="!p-1"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                const mov = ctx.movimiento;
                                                                if (mov.tercero_id) setTerceroId(mov.tercero_id)
                                                                if (mov.centro_costo_id) setCentroCostoId(mov.centro_costo_id)
                                                                if (mov.concepto_id) setConceptoId(mov.concepto_id)
                                                            }}
                                                            title="Copiar clasificación"
                                                        >
                                                            <Copy className="h-4 w-4" />
                                                        </Button>
                                                    )
                                                },
                                                {
                                                    key: 'score',
                                                    header: <TableHeaderCell>%</TableHeaderCell>,
                                                    width: 'w-14',
                                                    align: 'center',
                                                    accessor: (ctx: any) => (
                                                        <span className={`font-semibold text-sm ${
                                                            ctx.score >= 80 ? 'text-green-600' :
                                                            ctx.score >= 50 ? 'text-yellow-600' : 'text-gray-400'
                                                        }`}>
                                                            {ctx.score}%
                                                        </span>
                                                    )
                                                },
                                                fechaColumn<any>(
                                                    'fecha',
                                                    <TableHeaderCell>Fecha</TableHeaderCell>,
                                                    (ctx: any) => ctx.movimiento.fecha,
                                                    { width: 'w-24', sortable: false }
                                                ),
                                                {
                                                    key: 'tercero',
                                                    header: <TableHeaderCell>Tercero</TableHeaderCell>,
                                                    accessor: (ctx: any) => <div className="text-gray-900 font-medium">{ctx.movimiento.tercero_display?.split('-')[1] || '-'}</div>
                                                },
                                                {
                                                    key: 'clasificacion',
                                                    header: <TableHeaderCell>Clasificación</TableHeaderCell>,
                                                    accessor: (ctx: any) => <div className="text-xs text-gray-500">{ctx.movimiento.centro_costo_display?.split('-')[1]} / {ctx.movimiento.concepto_display?.split('-')[1]}</div>
                                                },
                                                monedaColumn<any>(
                                                    'valor',
                                                    <TableHeaderCell>Valor</TableHeaderCell>,
                                                    (ctx: any) => {
                                                        const mov = ctx.movimiento;
                                                        const isUsd = mov.cuenta_display?.toLowerCase().includes('usd') || (mov.usd && mov.usd !== 0);
                                                        return isUsd ? (mov.usd || 0) : mov.valor;
                                                    },
                                                    (ctx: any) => {
                                                        const mov = ctx.movimiento;
                                                        const isUsd = mov.cuenta_display?.toLowerCase().includes('usd') || (mov.usd && mov.usd !== 0);
                                                        return isUsd ? 'USD' : 'COP';
                                                    },
                                                    { sortable: false }
                                                ),
                                                {
                                                    key: 'referencia',
                                                    header: <TableHeaderCell>Referencia</TableHeaderCell>,
                                                    width: 'w-28',
                                                    accessor: (ctx: any) => <span className="font-medium text-gray-900">{ctx.movimiento.referencia || '-'}</span>
                                                },
                                                textoColumn<any>(
                                                    'descripcion',
                                                    <TableHeaderCell>Descripción</TableHeaderCell>,
                                                    (ctx: any) => ctx.movimiento.descripcion,
                                                    { cellClassName: 'text-xs text-gray-500 max-w-xs line-clamp-3', sortable: false }
                                                )
                                            ]}
                                            getRowKey={(ctx: any) => ctx.movimiento.id}
                                            showActions={false}
                                            className="border-none"
                                            emptyMessage="Sin historial"
                                        />
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
                        <ArrowRight className="h-16 w-16 mb-4 opacity-20" />
                        <p className="text-xl font-medium">Seleccione un movimiento para clasificar</p>
                    </div>
                )}
            </div>



            <TerceroModal
                isOpen={showTerceroModal}
                tercero={null}
                initialValues={modalInitialValues}
                onClose={() => setShowTerceroModal(false)}
                onSave={handleGuardarTercero}
            />

            <MovimientoModal
                isOpen={showAdvancedModal}
                onClose={() => setShowAdvancedModal(false)}
                movimiento={movimientoActual ? {
                    ...movimientoActual,
                    // Pasar clasificación actual del editor al modal
                    tercero_id: terceroId ?? movimientoActual.tercero_id,
                    centro_costo_id: centroCostoId ?? movimientoActual.centro_costo_id,
                    concepto_id: conceptoId ?? movimientoActual.concepto_id,
                    detalle: detalle || movimientoActual.detalle
                } : null}
                onSave={handleGuardarAvanzado}
                mode="edit"
            />

            {/* Modal de Confirmación de Eliminación */}
            {showDeleteModal && movimientoActual && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
                        {/* Header */}
                        <div className="bg-red-600 text-white px-6 py-4">
                            <h2 className="text-xl font-bold flex items-center gap-2">
                                <Trash2 className="h-6 w-6" />
                                Confirmar Eliminación
                            </h2>
                        </div>

                        {/* Body */}
                        <div className="p-6">
                            <p className="text-gray-700 mb-4">
                                ¿Está seguro que desea eliminar este movimiento?
                            </p>
                            <div className="bg-gray-50 rounded-lg p-4 mb-4">
                                <p className="text-sm text-gray-600 mb-1">
                                    <strong>ID:</strong> {movimientoActual.id}
                                </p>
                                <p className="text-sm text-gray-600 mb-1">
                                    <strong>Fecha:</strong> {new Date(movimientoActual.fecha).toLocaleDateString('es-CO')}
                                </p>
                                <p className="text-sm text-gray-600 mb-1">
                                    <strong>Descripción:</strong> {movimientoActual.descripcion}
                                </p>
                                <p className="text-sm text-gray-600">
                                    <strong>Valor:</strong>{' '}
                                    <CurrencyDisplay
                                        value={movimientoActual.valor}
                                        currency="COP"
                                        alignRight={false}
                                    />
                                </p>
                            </div>
                            <p className="text-red-600 text-sm font-medium">
                                Esta acción no se puede deshacer.
                            </p>
                        </div>

                        {/* Footer */}
                        <div className="px-6 py-4 bg-gray-50 flex justify-end gap-3">
                            <button
                                onClick={() => setShowDeleteModal(false)}
                                className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition"
                                disabled={deleting}
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={eliminarMovimiento}
                                disabled={deleting}
                                className="px-4 py-2 text-white bg-red-600 rounded-lg hover:bg-red-700 transition disabled:opacity-50 flex items-center gap-2"
                            >
                                {deleting ? (
                                    <>
                                        <RefreshCw className="h-4 w-4 animate-spin" />
                                        Eliminando...
                                    </>
                                ) : (
                                    <>
                                        <Trash2 className="h-4 w-4" />
                                        Eliminar
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <MessageModal message={msgModal?.message ?? null} type={msgModal?.type} onClose={() => setMsgModal(null)} />

            {/* Modal de Confirmación de Lote */}
            {showBatchModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl shadow-2xl max-w-5xl w-full mx-4 max-h-[90vh] overflow-hidden flex flex-col">
                        {/* Header */}
                        <div className="bg-purple-600 text-white px-6 py-4">
                            <h2 className="text-xl font-bold flex items-center gap-2">
                                <Layers className="h-6 w-6" />
                                Confirmar Clasificación en Lote
                            </h2>
                        </div>

                        {/* Content */}
                        <div className="p-6 overflow-auto flex-1">
                            <div className="mb-4 bg-gray-50 rounded-lg p-4">
                                <div className="flex gap-4">
                                    <div className="flex-1">
                                        <label className="block text-sm text-gray-700 mb-1">Patrón de búsqueda:</label>
                                        <input
                                            type="text"
                                            value={batchPatron}
                                            onChange={(e) => setBatchPatron(e.target.value)}
                                            onKeyDown={(e) => e.key === 'Enter' && handleRefreshPreview()}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                            placeholder="Escriba patrón para buscar..."
                                        />
                                    </div>
                                    <div className="w-48">
                                        <label className="block text-sm text-gray-700 mb-1">Referencia:</label>
                                        <input
                                            type="text"
                                            value={batchReferencia || ''}
                                            onChange={(e) => setBatchReferencia(e.target.value || undefined)}
                                            onKeyDown={(e) => e.key === 'Enter' && handleRefreshPreview()}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                            placeholder="Todas"
                                        />
                                    </div>
                                    <div className="flex items-end">
                                        <button
                                            onClick={handleRefreshPreview}
                                            disabled={loadingBatch}
                                            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition flex items-center gap-2 disabled:opacity-50"
                                        >
                                            {loadingBatch ? (
                                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                                            ) : (
                                                <RefreshCw className="h-4 w-4" />
                                            )}
                                            Refrescar
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className="mb-4 grid grid-cols-3 gap-4 text-sm">
                                <div className="bg-blue-50 rounded-lg p-3">
                                    <p className="text-gray-500">Tercero</p>
                                    <p className="font-medium">{terceros.find(t => t.id === terceroId)?.nombre || '-'}</p>
                                </div>
                                <div className="bg-green-50 rounded-lg p-3">
                                    <p className="text-gray-500">Centro de Costo</p>
                                    <p className="font-medium">{centrosCostos.find(g => g.id === centroCostoId)?.nombre || '-'}</p>
                                </div>
                                <div className="bg-yellow-50 rounded-lg p-3">
                                    <p className="text-gray-500">Concepto</p>
                                    <p className="font-medium">{conceptos.find(c => c.id === conceptoId)?.nombre || '-'}</p>
                                </div>
                            </div>

                            <div className="border rounded-lg overflow-hidden">
                                <BatchClassificationPreviewTable
                                    movimientos={batchPreview}
                                    selectedIds={batchSelectedIds}
                                    onSelectionChange={(selected) => setBatchSelectedIds(selected as Set<number>)}
                                    loading={loadingBatch}
                                />
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="border-t px-6 py-4 flex justify-end gap-4 bg-gray-50">
                            <button
                                onClick={() => {
                                    setShowBatchModal(false)
                                    setBatchPreview([])
                                }}
                                className="px-6 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition"
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={confirmarLote}
                                disabled={batchSelectedIds.size === 0}
                                className="px-6 py-2 rounded-lg bg-purple-600 text-white hover:bg-purple-700 transition disabled:opacity-50 flex items-center gap-2"
                            >
                                <CheckCircle className="h-5 w-5" />
                                Aplicar a {batchSelectedIds.size} Movimientos
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
